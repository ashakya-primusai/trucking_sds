// tdp-sections.jsx — TruckDispatch Pro landing sections (refined / quiet)

// ─── Reveal primitives ────────────────────────────────────────────
function useRevealObserver() {
  React.useEffect(() => {
    const targets = Array.from(document.querySelectorAll("[data-reveal]"));
    targets.forEach((t) => t.classList.add("tdp-pre-reveal"));

    let observer;
    if (typeof IntersectionObserver !== "undefined") {
      observer = new IntersectionObserver((entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("in");
            observer.unobserve(e.target);
          }
        });
      }, { threshold: 0.1, rootMargin: "0px 0px -5% 0px" });
      targets.forEach((t) => observer.observe(t));
    }

    const safety = setTimeout(() => {
      targets.forEach((t) => t.classList.add("in"));
    }, 1500);

    return () => { clearTimeout(safety); if (observer) observer.disconnect(); };
  }, []);
}

// ─── Typewriter highlight ─────────────────────────────────────────
function useInView(ref) {
  const [inView, setInView] = React.useState(false);
  React.useEffect(() => {
    if (!ref.current || typeof IntersectionObserver === "undefined") {
      setInView(true);
      return;
    }
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setInView(true); observer.disconnect(); } },
      { threshold: 0.15 }
    );
    observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);
  return inView;
}

function TypewriterHighlight({ children, delay = 0 }) {
  const ref = React.useRef(null);
  const inView = useInView(ref);
  const words = String(children).split(" ").filter(Boolean);
  return (
    <span ref={ref}>
      {words.map((word, i) => (
        <span
          key={i}
          className={"tdp-tw-word" + (inView ? " tdp-tw-play" : "")}
          style={{ "--tw-delay": `${delay + i * 220}ms` }}
        >
          {word}{" "}
        </span>
      ))}
    </span>
  );
}

// ─── Logo ─────────────────────────────────────────────────────────
function Logo() {
  return (
    <a href="#" className="tdp-logo">
      <svg width="22" height="22" viewBox="0 0 22 22" aria-hidden="true">
        <circle cx="11" cy="11" r="10" fill="none" stroke="currentColor" strokeWidth="1.5" />
        <circle cx="11" cy="11" r="3" fill="currentColor" />
      </svg>
      <span>TruckDispatch <em>Pro</em></span>
    </a>
  );
}

// ─── Nav ──────────────────────────────────────────────────────────
function Nav() {
  return (
    <header className="tdp-nav">
      <div className="tdp-nav-inner">
        <Logo />
        <nav className="tdp-nav-links">
          <a href="#features">Features</a>
          <a href="#how">How it works</a>
          <a href="#impact">Impact</a>
          <a href="#pricing">Pricing</a>
        </nav>
        <div className="tdp-nav-cta">
          <a href="#" className="tdp-link-quiet">Sign in</a>
          <a href="#contact" className="tdp-btn tdp-btn-sm">Book a demo</a>
        </div>
      </div>
    </header>
  );
}

// ─── Hero ─────────────────────────────────────────────────────────
function Hero() {
  return (
    <section className="tdp-hero">
      <img src="assets/hero-bg.jpg" alt="" className="tdp-hero-bg-img" aria-hidden="true" />
      <div className="tdp-container">
        <div className="tdp-status" data-reveal>
          <span className="tdp-status-dot" />
          <span className="tdp-mono">System operational</span>
        </div>

        <h1 className="tdp-hero-h">
          <TypewriterHighlight delay={300}>Run your dispatch like a high-performance system.</TypewriterHighlight>
          <span className="tdp-hero-aside">Not a manual operation.</span>
        </h1>

        <p className="tdp-hero-sub" data-reveal>
          TruckDispatch Pro automates your entire load lifecycle — from discovery to delivery — with AI that communicates, decides, and executes in real time.
        </p>

        <div className="tdp-hero-cta" data-reveal>
          <a href="#contact" className="tdp-btn">Book a demo</a>
          <a href="#features" className="tdp-btn-text">See product in action <span className="tdp-arrow">→</span></a>
        </div>

        <div className="tdp-hero-tags" data-reveal>
          <span>Fewer delays</span>
          <span className="tdp-tag-dot" />
          <span>Faster decisions</span>
          <span className="tdp-tag-dot" />
          <span>Higher margins</span>
        </div>
      </div>

      <div className="tdp-hero-stage" data-reveal>
        <HeroDashboard />
      </div>
    </section>
  );
}

// ─── Hero dashboard preview ────────────────────────────────────────
function HeroDashboard() {
  return (
    <div className="tdp-screen">
      <div className="tdp-screen-chrome">
        <div className="tdp-chrome-dots"><i /><i /><i /></div>
        <div className="tdp-chrome-url tdp-mono">app.truckdispatch.pro · operations</div>
        <div className="tdp-chrome-actions tdp-mono">
          <span className="tdp-live-dot" />
          <span>LIVE</span>
        </div>
      </div>
      <img src="assets/load-dashboard.png" alt="TruckDispatch Pro load operations dashboard" style={{ width: "100%", display: "block" }} />
    </div>
  );
}

// ─── Paradigm shift (manual vs AI) ────────────────────────────────
function ParadigmShift() {
  const manual = [
    "Chasing brokers",
    "Switching between tools",
    "Reacting to issues late",
    "Losing time in follow-ups",
  ];
  const ai = [
    "Automated negotiation",
    "Unified single platform",
    "Proactive issue resolution",
    "Instant communication",
  ];
  return (
    <section className="tdp-paradigm">
      <div className="tdp-container">
        <div className="tdp-eyebrow tdp-mono" data-reveal>The paradigm shift</div>
        <h2 className="tdp-section-h">
          <TypewriterHighlight>Dispatch hasn't evolved. Until now.</TypewriterHighlight>
        </h2>
        <p className="tdp-section-sub" data-reveal>
          TruckDispatch Pro doesn't just help you manage loads. It actively moves them forward.
        </p>

        <div className="tdp-shift-grid">
          <div className="tdp-shift-col" data-reveal>
            <div className="tdp-shift-label tdp-mono">The manual era</div>
            <ul>
              {manual.map((m) => (
                <li key={m}><span className="tdp-shift-mark">×</span>{m}</li>
              ))}
            </ul>
          </div>
          <div className="tdp-shift-col on" data-reveal>
            <div className="tdp-shift-label tdp-mono">The AI-powered system era</div>
            <ul>
              {ai.map((a) => (
                <li key={a}><span className="tdp-shift-mark good">✓</span>{a}</li>
              ))}
            </ul>
          </div>
        </div>

        <p className="tdp-shift-caption" data-reveal>A system that runs your operations for you.</p>
      </div>
    </section>
  );
}

// ─── Redefining dispatch ──────────────────────────────────────────
function RedefiningDispatch() {
  return (
    <section className="tdp-redefine">
      <div className="tdp-container">
        <div className="tdp-eyebrow tdp-mono" data-reveal>Redefining dispatch</div>
        <h2 className="tdp-section-h" data-reveal>
          An operating system for modern dispatch.
        </h2>
        <p className="tdp-redefine-lede" data-reveal>
          This is not a dashboard. This is not a TMS. This is a decision-making engine that runs your operations end-to-end.
        </p>

        <div className="tdp-redefine-grid">
          <RedefineItem n="01" label="Tracks every load" />
          <RedefineItem n="02" label="Communicates automatically" />
          <RedefineItem n="03" label="Resolves bottlenecks" />
          <RedefineItem n="04" label="Optimizes outcomes in real time" />
        </div>
      </div>
    </section>
  );
}

function RedefineItem({ n, label }) {
  return (
    <div className="tdp-redefine-item" data-reveal>
      <span className="tdp-mono tdp-dim">{n}</span>
      <p>{label}</p>
    </div>
  );
}

// ─── Product in action — sticky scroll ────────────────────────────
function ProductInAction() {
  const features = [
    {
      n: "01",
      label: "Operations dashboard",
      h: "See everything. Act instantly.",
      body: "Your entire operation, in one intelligent view: active loads, alerts, pipeline status, and priorities — with only what needs action surfaced to the top.",
      img: "assets/load-dashboard.png",
    },
    {
      n: "02",
      label: "Communication hub",
      h: "All conversations. Fully in control.",
      body: "Centralize every channel into a single context-aware inbox. AI analyzes intent and suggests responses instantly, linked directly to the relevant load.",
      img: "assets/communication.png",
    },
    {
      n: "03",
      label: "AI automation engine",
      h: "Let the system do the work.",
      body: "The core of TruckDispatch Pro. Rules trigger instantly based on market conditions, load status, and carrier behavior — so you stay ahead without lifting a finger.",
      img: "assets/scheduling.png",
    },
  ];

  const [active, setActive] = React.useState(0);
  const sectionRef = React.useRef(null);

  React.useEffect(() => {
    const onScroll = () => {
      if (!sectionRef.current) return;
      const rect = sectionRef.current.getBoundingClientRect();
      const sectionH = sectionRef.current.offsetHeight;
      const vh = window.innerHeight;
      const scrolled = Math.max(0, -rect.top);
      const scrollable = sectionH - vh;
      if (scrollable <= 0) return;
      const progress = Math.min(1, scrolled / scrollable);
      const idx = Math.min(features.length - 1, Math.floor(progress * features.length));
      setActive(idx);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const f = features[active];

  return (
    <section
      ref={sectionRef}
      className="tdp-sf-section"
      id="features"
      style={{ height: `${features.length * 100}vh` }}
    >
      <div className="tdp-sf-sticky">
        <div className="tdp-sf-imgs">
          {features.map((feat, i) => (
            <img
              key={i}
              src={feat.img}
              alt={feat.label}
              className={"tdp-sf-img" + (i === active ? " tdp-sf-img-on" : "")}
            />
          ))}
          <div className="tdp-sf-counter">
            <div className="tdp-sf-counter-line" />
            <span className="tdp-mono">{String(active + 1).padStart(2, "0")}</span>
          </div>
          <div className="tdp-sf-dots">
            {features.map((_, i) => (
              <span key={i} className={"tdp-sf-dot" + (i === active ? " on" : "")} />
            ))}
          </div>
        </div>
        <div className="tdp-sf-foot">
          <div className="tdp-sf-foot-inner">
            <div className="tdp-sf-left" key={active}>
              <div className="tdp-mono tdp-dim">Feature {f.n}</div>
              <h3 className="tdp-sf-h">{f.h}</h3>
            </div>
            <p className="tdp-sf-body" key={"b" + active}>{f.body}</p>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Cap UI previews ──────────────────────────────────────────────
function CapLoadMgmt() {
  const stages = [
    { l: "REC", n: 3, w: 40 },
    { l: "NEG", n: 5, w: 65, on: true },
    { l: "ASS", n: 2, w: 80 },
    { l: "TRN", n: 8, w: 55 },
    { l: "DEL", n: 12, w: 90 },
  ];
  return (
    <div className="tdp-cpv">
      <div className="tdp-cpv-pipeline">
        {stages.map(s => (
          <div key={s.l} className={"tdp-cpv-stage" + (s.on ? " on" : "")}>
            <div className="tdp-cpv-bar"><i style={{ width: s.w + "%" }} /></div>
            <b>{s.n}</b>
            <span className="tdp-mono">{s.l}</span>
          </div>
        ))}
      </div>
      {[
        { id: "AB01", route: "Chicago → Atlanta", rate: "$1,700", ok: true },
        { id: "WJ19", route: "Topeka → Dallas", rate: "$1,038", ok: false },
        { id: "SK04", route: "El Paso → Glendale", rate: "$2,140", ok: true },
      ].map(r => (
        <div key={r.id} className={"tdp-cpv-row" + (!r.ok ? " warn" : "")}>
          <span className="tdp-mono tdp-dim">{r.id}</span>
          <span>{r.route}</span>
          <b>{r.rate}</b>
        </div>
      ))}
    </div>
  );
}

function CapDetails() {
  return (
    <div className="tdp-cpv">
      <div className="tdp-cpv-card">
        <div className="tdp-cpv-card-h">
          <span className="tdp-mono tdp-dim">#AB01 · Chicago → Atlanta</span>
          <span className="tdp-tag tdp-tag-ok tdp-mono">ACTIVE</span>
        </div>
        <div className="tdp-cpv-metrics">
          <div className="tdp-cpv-metric"><span className="tdp-mono tdp-dim">Revenue</span><b>$2,140</b></div>
          <div className="tdp-cpv-metric"><span className="tdp-mono tdp-dim">Fuel est.</span><b>$340</b></div>
          <div className="tdp-cpv-metric"><span className="tdp-mono tdp-dim">Net margin</span><b className="tdp-pos">$1,800</b></div>
          <div className="tdp-cpv-metric"><span className="tdp-mono tdp-dim">Rate/mi</span><b>$2.53</b></div>
        </div>
        <div className="tdp-cpv-progress-row">
          <div className="tdp-cpv-progress-bar">
            <div style={{ width: "62%" }} />
          </div>
          <span className="tdp-mono tdp-dim">847 mi · stop 2 of 3</span>
        </div>
      </div>
    </div>
  );
}

function CapLoadCreate() {
  return (
    <div className="tdp-cpv">
      <div className="tdp-cpv-form">
        {[
          { label: "Origin", val: "Chicago, IL" },
          { label: "Destination", val: "Atlanta, GA" },
          { label: "Rate", val: "$2,200" },
          { label: "Equipment", val: "Dry Van ▾" },
        ].map(f => (
          <div key={f.label} className="tdp-cpv-field">
            <span className="tdp-mono tdp-dim">{f.label}</span>
            <span className="tdp-cpv-val">{f.val}</span>
          </div>
        ))}
        <div className="tdp-cpv-submit tdp-mono">+ Create Load</div>
      </div>
    </div>
  );
}

function CapDocs() {
  return (
    <div className="tdp-cpv">
      {[
        { name: "Bill of Lading #8821", status: "SIGNED", ok: true },
        { name: "Proof of Delivery", status: "PENDING", ok: false },
        { name: "Rate Confirmation #4821", status: "READY", ok: true },
        { name: "Invoice #INV-0042", status: "SENT", ok: true },
      ].map(d => (
        <div key={d.name} className="tdp-cpv-doc">
          <span className="tdp-cpv-doc-icon tdp-mono">▤</span>
          <span className="tdp-cpv-doc-name">{d.name}</span>
          <span className={"tdp-tag tdp-mono " + (d.ok ? "tdp-tag-ok" : "tdp-tag-warn")}>{d.status}</span>
        </div>
      ))}
    </div>
  );
}

function CapRouting() {
  const stops = [
    { city: "Chicago, IL", note: "Origin" },
    { city: "Memphis, TN", note: "290 mi" },
    { city: "Birmingham, AL", note: "503 mi" },
    { city: "Atlanta, GA", note: "658 mi" },
  ];
  return (
    <div className="tdp-cpv">
      <div className="tdp-cpv-stops">
        {stops.map((s, i) => (
          <div key={s.city} className="tdp-cpv-stop">
            <div className="tdp-cpv-stop-track">
              <div className={"tdp-cpv-stop-dot" + (i === 0 || i === stops.length - 1 ? " end" : "")} />
              {i < stops.length - 1 && <div className="tdp-cpv-stop-line" />}
            </div>
            <div className="tdp-cpv-stop-info">
              <span>{s.city}</span>
              <span className="tdp-mono tdp-dim">{s.note}</span>
            </div>
          </div>
        ))}
      </div>
      <div className="tdp-cpv-route-foot">
        <span className="tdp-mono tdp-dim">658 mi total</span>
        <span className="tdp-mono tdp-pos">$0.89/mi</span>
        <span className="tdp-mono tdp-dim">Best route ✓</span>
      </div>
    </div>
  );
}

function CapAlerts() {
  return (
    <div className="tdp-cpv">
      {[
        { level: "URGENT", msg: "Load #WJ19 delayed 3h at Memphis", warn: true },
        { level: "ACTION", msg: "Rate below floor on AB01 — review", warn: true },
        { level: "INFO",   msg: "Driver ETA updated to 2:30 PM", ok: true },
        { level: "OPP",    msg: "High-rate load available nearby", ok: true },
      ].map(a => (
        <div key={a.msg} className="tdp-cpv-alert">
          <span className={"tdp-tag tdp-mono " + (a.warn ? "tdp-tag-warn" : "tdp-tag-ok")}>{a.level}</span>
          <span className="tdp-cpv-alert-msg">{a.msg}</span>
        </div>
      ))}
    </div>
  );
}

// ─── More capabilities (6 cards) ──────────────────────────────────
function MoreCapabilities() {
  const caps = [
    { h: "Load management",    preview: <CapLoadMgmt />,    points: ["Track stages from discovery to delivery", "Detect bottlenecks instantly", "Take action without switching screens"] },
    { h: "Details & insights", preview: <CapDetails />,     points: ["Route and stop-level visibility", "Profit and cost insights", "Lifecycle progress tracking"] },
    { h: "Load creation",      preview: <CapLoadCreate />,  points: ["Structured setup in minutes", "AI-powered recommendations", "Workflow starts immediately"] },
    { h: "Document management",preview: <CapDocs />,        points: ["BOLs, PODs, invoices, contracts", "Status tracking & quick access", "Load-linked documentation"] },
    { h: "Route optimization", preview: <CapRouting />,     points: ["Route visualization", "Fuel and profit insights", "Smarter routing decisions"] },
    { h: "AI alerts",          preview: <CapAlerts />,      points: ["Stuck load detection", "Priority alerts", "Revenue opportunities"] },
  ];
  return (
    <section className="tdp-caps">
      <div className="tdp-container">
        <h2 className="tdp-section-h" data-reveal>More capabilities, built for speed.</h2>
        <div className="tdp-caps-grid">
          {caps.map((c, i) => (
            <article key={c.h} className="tdp-cap" data-reveal>
              {c.preview}
              <div className="tdp-cap-n tdp-mono">{String(i + 1).padStart(2, "0")}</div>
              <h3>{c.h}</h3>
              <ul>{c.points.map(p => <li key={p}>{p}</li>)}</ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── How it works ─────────────────────────────────────────────────
function HowItWorks() {
  const steps = [
    "Loads enter the system",
    "AI initiates communication",
    "Documents & approvals handled",
    "Drivers are assigned intelligently",
    "Loads move in real time",
    "Insights optimize every step",
  ];
  return (
    <section className="tdp-how" id="how">
      <div className="tdp-container">
        <div className="tdp-eyebrow tdp-mono" data-reveal>System execution</div>
        <h2 className="tdp-section-h" data-reveal>How it works.</h2>

        <ol className="tdp-steps">
          {steps.map((s, i) => (
            <li key={i} data-reveal style={{ transitionDelay: `${i * 60}ms` }}>
              <span className="tdp-step-n tdp-mono">{String(i + 1).padStart(2, "0")}</span>
              <span>{s}</span>
            </li>
          ))}
        </ol>

        <p className="tdp-how-caption" data-reveal>
          Every step automated. Every decision optimized. Every load moving forward.
        </p>
      </div>
    </section>
  );
}

// ─── Why this wins (comparison) ───────────────────────────────────
function WhyThisWins() {
  const rows = [
    ["Manual workflows", "Automated execution"],
    ["Disconnected tools", "One unified system"],
    ["Reactive decisions", "Real-time intelligence"],
    ["Data visibility", "Actionable outcomes"],
  ];
  return (
    <section className="tdp-why">
      <div className="tdp-container">
        <h2 className="tdp-section-h" data-reveal>
          Why this wins.
          <span className="tdp-section-aside">Built to execute, not just manage.</span>
        </h2>

        <div className="tdp-compare" data-reveal>
          <div className="tdp-compare-head">
            <span className="tdp-mono tdp-dim">Others</span>
            <span className="tdp-mono">TruckDispatch Pro</span>
          </div>
          {rows.map(([a, b], i) => (
            <div key={i} className="tdp-compare-row">
              <span>{a}</span>
              <span className="tdp-compare-divider" />
              <b>{b}</b>
            </div>
          ))}
        </div>

        <p className="tdp-why-caption" data-reveal>The difference is execution. Every time.</p>
      </div>
    </section>
  );
}

// ─── Impact ───────────────────────────────────────────────────────
function Impact() {
  const items = [
    { h: "Reduce manual work and follow-ups", body: "Eliminate repetitive tasks and let AI handle communication." },
    { h: "Increase speed of operations", body: "Move loads faster with automated workflows and instant decisions." },
    { h: "Improve load profitability", body: "Optimize routes, reduce delays, and capture more margin." },
    { h: "Scale without increasing team size", body: "Handle more volume with the same resources through automation." },
  ];
  return (
    <section className="tdp-impact" id="impact">
      <div className="tdp-container">
        <div className="tdp-eyebrow tdp-mono" data-reveal>Real results</div>
        <h2 className="tdp-section-h" data-reveal>Impact.</h2>

        <div className="tdp-impact-grid">
          {items.map((it, i) => (
            <article key={i} className="tdp-impact-card" data-reveal style={{ transitionDelay: `${i * 70}ms` }}>
              <h3>{it.h}</h3>
              <p>{it.body}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Final CTA ────────────────────────────────────────────────────
function FinalCTA() {
  return (
    <section className="tdp-cta" id="contact">
      <div className="tdp-container">
        <h2 className="tdp-cta-h" data-reveal>
          Stop managing dispatch.<br />
          <span className="tdp-cta-soft">Start running it like a system.</span>
        </h2>
        <p data-reveal>See how TruckDispatch Pro transforms your operations from day one.</p>
        <div className="tdp-cta-actions" data-reveal>
          <a href="#" className="tdp-btn">Book a demo</a>
          <a href="#" className="tdp-btn tdp-btn-ghost">Start free trial</a>
        </div>
        <div className="tdp-cta-meta tdp-mono" data-reveal>
          <span>No credit card required</span>
          <span className="tdp-tag-dot" />
          <span>14-day free trial</span>
          <span className="tdp-tag-dot" />
          <span>Setup in minutes</span>
        </div>
      </div>
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────────
function TDPFooter() {
  const cols = [
    { h: "Product", links: ["Features", "Pricing", "Security", "Roadmap"] },
    { h: "Company", links: ["About", "Customers", "Careers", "Contact"] },
    { h: "Resources", links: ["Documentation", "API Reference", "Support", "Status"] },
    { h: "Legal", links: ["Privacy", "Terms", "Compliance"] },
  ];
  return (
    <footer className="tdp-footer">
      <div className="tdp-container">
        <div className="tdp-footer-grid">
          <div className="tdp-footer-brand">
            <Logo />
            <p>The operating system for modern dispatch operations. Built for scale, designed for execution.</p>
          </div>
          {cols.map((c) => (
            <div key={c.h} className="tdp-footer-col">
              <div className="tdp-mono tdp-dim">{c.h}</div>
              {c.links.map((l) => <a key={l} href="#">{l}</a>)}
            </div>
          ))}
        </div>
        <div className="tdp-footer-bottom">
          <span className="tdp-mono tdp-dim">© 2026 TruckDispatch Pro. All rights reserved.</span>
          <span className="tdp-mono tdp-dim">v4.2 · Status: operational</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, {
  useRevealObserver, Nav, Hero, ParadigmShift, RedefiningDispatch,
  ProductInAction, MoreCapabilities, HowItWorks, WhyThisWins, Impact,
  FinalCTA, TDPFooter,
});
